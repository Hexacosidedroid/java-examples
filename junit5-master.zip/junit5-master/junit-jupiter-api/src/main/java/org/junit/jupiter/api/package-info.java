/**
 * JUnit Jupiter API for writing tests.
 */

package org.junit.jupiter.api;
