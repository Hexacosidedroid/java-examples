/**
 * JUnit Jupiter API for influencing parallel test execution.
 */

package org.junit.jupiter.api.parallel;
