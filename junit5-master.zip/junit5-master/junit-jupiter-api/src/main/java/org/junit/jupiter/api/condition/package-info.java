/**
 * Annotation-based conditions for enabling or disabling tests in JUnit Jupiter.
 */

package org.junit.jupiter.api.condition;
