/**
 * Internal predicate classes used by test discovery within the JUnit Jupiter test engine.
 */

package org.junit.jupiter.engine.discovery.predicates;
